# TechNova — Flask Multi-Page Website
**Lab #07 | Introduction to Computing (SE-105L)**

---

## 📁 Project Structure

```
flask_lab/
├── app.py                  # Main Flask application
├── templates/
│   ├── base.html           # Shared layout (navbar, footer, flash messages)
│   ├── home.html           # Home page  (/)
│   ├── about.html          # About page (/about)
│   ├── services.html       # Services   (/services)
│   ├── gallery.html        # Gallery    (/gallery)
│   ├── contact.html        # Contact    (/contact)
│   ├── login.html          # Login      (/login)
│   └── register.html       # Register   (/register)
├── static/
│   └── css/
│       └── style.css       # All styles
└── README.md
```

---

## ⚙️ How to Run

### 1. Install Flask
```bash
pip install flask
```

### 2. Run the App
```bash
python app.py
```

### 3. Open in Browser
```
http://127.0.0.1:5000
```

---

## 🔐 Login & Registration (Simulated)

- User data is stored **in-memory** (Python dictionary) — no database or files.
- Registering a new account stores credentials temporarily in `users = {}`.
- Logging in checks if the username/password match what's in that dictionary.
- **Data resets when the server restarts.** This is intentional for this lab.

### Test Flow:
1. Go to `/register` → fill in the form → click Register
2. Go to `/login` → use the same username/password → click Login
3. You'll be greeted by name in the navbar!

---

## 📄 Pages

| Route       | Description                        |
|-------------|-------------------------------------|
| `/`         | Home with hero, stats, features     |
| `/about`    | Team info and company story         |
| `/services` | Service cards + comparison table    |
| `/gallery`  | Visual grid gallery                 |
| `/contact`  | Contact form with flash feedback    |
| `/login`    | Login form                         |
| `/register` | Registration form                  |
| `/logout`   | Clears session and redirects home   |

---

## ✅ Features
- Flask routing with `render_template`
- Flash messages for form feedback
- Session-based login state
- Responsive design (mobile-friendly)
- Modern dark-themed UI with animations
